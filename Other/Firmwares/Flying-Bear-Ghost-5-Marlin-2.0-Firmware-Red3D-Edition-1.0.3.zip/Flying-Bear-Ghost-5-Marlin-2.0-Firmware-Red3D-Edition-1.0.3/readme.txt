(Per 2 tmc)

metti la cartella asset e il file robin nano nella memoria

e accendi la macchina

una volta aggiornato fai il reset della eprom