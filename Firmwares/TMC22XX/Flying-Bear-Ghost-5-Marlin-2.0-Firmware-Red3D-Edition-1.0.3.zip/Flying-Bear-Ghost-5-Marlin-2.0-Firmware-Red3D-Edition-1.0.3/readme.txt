QUESTO FIRMWARE è PER CHI HA INSTALLATO TUTTI E 4 I TMC2209

1) metti la cartella asset e il file robin nano nella memoria
2) accendi la macchina
3) una volta aggiornato fai il reset della eprom (Configurazione...eprom... reset...)