# Copyright (c) 2021
# MKS Plugin is released under the terms of the AGPLv3 or higher.

STOP_UPDATE = "mkswifi/stopupdate"
AUTO_PRINT = "mkswifi/autoprint"
SAVE_PATH = "mkswifi/savepath"
MANUAL_INSTANCES = "mkswifi/manual_instances"

# Errors
EXCEPTION_MESSAGE = "An exception occurred in network connection: %s"
