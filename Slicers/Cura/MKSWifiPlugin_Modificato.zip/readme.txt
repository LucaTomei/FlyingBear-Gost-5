Mac OS Plugins Folder:

~/Library/Application\ Support/cura/4.8/plugins