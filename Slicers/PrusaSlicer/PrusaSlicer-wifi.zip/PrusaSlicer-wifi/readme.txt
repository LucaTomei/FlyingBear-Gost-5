# Installazione

è necessario spostare il file .app nella cartella applicazioni di mac os

## Abilitare stampa wi-fi

Printer Settings -> Premi l'ingranaggio, metti MKS e l'ip

# Disinstallazione

se vuoi tornare alla 2.3 devi eliminare "host_type = mks" dal file  ~/Library/Application\ Support/PrusaSlicer/physical_printer/FBG5.ini
